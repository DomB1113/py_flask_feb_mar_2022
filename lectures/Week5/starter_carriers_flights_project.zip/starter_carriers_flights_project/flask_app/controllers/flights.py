from flask_app import app
from flask import render_template, redirect, request, session
# Import your models
# from flask_app.models import flight

# Define our routes!  We'll define all of them in Monday's office hour!
@app.route("/flights")
def all_flights():
    pass